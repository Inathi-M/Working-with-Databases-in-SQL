select COUNT(customerNumber) AS numCalls from customers
