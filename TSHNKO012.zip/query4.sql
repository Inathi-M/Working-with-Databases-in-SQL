select avg(amount) AS mean, SUM(amount) AS total 
from payments
