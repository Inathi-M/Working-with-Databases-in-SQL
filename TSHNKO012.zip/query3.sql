select phone from customers 
Where salesRepEmployeeNumber is null;