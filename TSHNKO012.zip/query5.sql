select city, phone from offices
where city = 'London' or city = 'Paris'